<div class="mainicon">
<div class="container">
    <div class="row">
        <div class="col icones">
            <a href="produtos.php?c=bovino">
                <img class="icones img-fluid" src="assets/icone6.jpeg" alt="">
            </a>
        </div>
        <div class="col icones">
        <a href="produtos.php?c=suino">

            <img class="icones img-fluid" src="assets/icone3.jpeg" alt="">
</a>

        </div>
    </div>
    
    <div class="row">
        <div class="col icones">
        <a href="produtos.php?c=equino">

            <img class="icones img-fluid" src="assets/icone2.jpeg" alt="">
        </a>
        </div>
        <div class="col icones">
        <a href="produtos.php?c=aves">

            <img class="icones img-fluid" src="assets/icone5.jpeg" alt="">
        </a>
        </div>
    </div>
    <div class="row">
        <div class="col icones">
        <a href="produtos.php?c=graos">

            <img class="icones img-fluid" src="assets/icone1.jpeg" alt="">
        </a>
        </div>
        <div class="col icones">
        <a href="produtos.php?c=farelos">

            <img class="icones img-fluid" src="assets/icone4.jpeg" alt="">
        </a>
        </div>
    </div>
</div>
</div>
<br><br>
<?php require 'pages/footer.php'; ?>
